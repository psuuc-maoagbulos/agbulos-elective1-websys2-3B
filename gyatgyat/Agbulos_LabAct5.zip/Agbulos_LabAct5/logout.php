<?php
// Perform logout operations, e.g., session_destroy()
// Redirect to login page
header("Location: login.php");
exit();
?>
